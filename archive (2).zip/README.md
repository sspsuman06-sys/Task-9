# E-Commerce Orders Dataset – 10K Synthetic Transactions with Segments

## 📖 Overview
This dataset contains **10,000 synthetic e-commerce transactions** with rich attributes, including customer segmentation, multiple product categories, pricing, and order timestamps.
It is ideal for **data analysis, visualization, and machine learning** in domains like sales forecasting, customer behavior analysis, and product performance tracking.

## 📂 Data Dictionary
| Column Name        | Description |
|--------------------|-------------|
| **order_id**       | Unique ID for each transaction |
| **user_id**        | Unique ID for each customer |
| **product_id**     | Unique ID for each product |
| **category**       | Product category (e.g., Electronics, Clothing) |
| **price**          | Unit price of the product in USD |
| **qty**            | Quantity purchased |
| **total_price**    | price × qty |
| **order_date**     | ISO timestamp of the order |
| **country**        | Customer's country |
| **customer_segment** | Segment based on total purchase value: Low-Value, Mid-Value, High-Value |

## 🔍 Potential Use Cases
- **Exploratory Data Analysis (EDA)** – trends in sales, top countries, peak purchase times.
- **Customer Segmentation** – build RFM models, churn prediction.
- **Price Analysis** – detect price trends by category and country.
- **Forecasting** – time series prediction of sales.
- **Market Basket Analysis** – identify frequently purchased item combinations.

## 🌍 Countries Included
United States, United Kingdom, Canada, Germany, France, India, Australia, Brazil, Netherlands, Spain, Italy, Mexico, Japan, China, South Africa.

## 🏷️ Tags
`ecommerce` `retail` `sales` `synthetic-data` `analytics` `customer-segmentation` `time-series`

## 📜 License
**[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)** – You are free to share and adapt with attribution.
